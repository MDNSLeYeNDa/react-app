import React from 'react';
import ReactDOM from 'react-dom';
import renderer from 'react-test-renderer';
import App, { Search, Button, Table} from './App';



describe('Search', () => {

  it('renders', () => {
    const div = document.createElement('div');
    ReactDOM.render(<Search>Search</Search>, div);
  });

  test('snapshots', () => {
    const component = renderer.create(<Search>Search</Search>);
    let tree = component.toJSON();
    expect(tree).toMatchSnapshot();
  });
});


describe('Button', () => {

  it('renders', () => {
    const div = document.createElement('div');
    ReactDOM.render(<Button>Give Me More</Button>, div);
  });

  test('snapshots', () => {
    const component = renderer.create(<Button>Give Me More</Button>);
    let tree = component.toJSON();
    expect(tree).toMatchSnapshot();
  });
});

describe('Table', () => {
  const props = {
    list : [
      { id: '1', nombre: 'Kevin', apellidos: 'Martínez González', edad: 20, localidad: 'Santa Cruz de Tenerife', correo: 'kevin@gmail.com'},
      { id: '2', nombre: 'Juan', apellidos: 'Perez Perez', edad: 25, localidad: 'Santa Cruz de Tenerife', correo: 'juanpp@gmail.com'},
      { id: '3', nombre: 'Juana', apellidos: 'Perez Perez', edad: 25, localidad: 'Santa Cruz de Tenerife', correo: 'juanapp@gmail.com'},
      { id: '4', nombre: 'Juanjo', apellidos: 'Perez Perez', edad: 25, localidad: 'Santa Cruz de Tenerife', correo: 'juanjopp@gmail.com'},
      { id: '5', nombre: 'Juan Pedro', apellidos: 'Perez Perez', edad: 25, localidad: 'Santa Cruz de Tenerife', correo: 'juanpedropp@gmail.com'},
      { id: '6', nombre: 'Pedro', apellidos: 'Perez Perez', edad: 25, localidad: 'Santa Cruz de Tenerife', correo: 'pedropp@gmail.com'},
      { id: '7', nombre: 'Paco', apellidos: 'Perez Perez', edad: 25, localidad: 'Santa Cruz de Tenerife', correo: 'pacopp@gmail.com'},
      { id: '8', nombre: 'Adrian', apellidos: 'Perez Perez', edad: 25, localidad: 'Santa Cruz de Tenerife', correo: 'adrianpp@gmail.com'},
      { id: '9', nombre: 'Luis', apellidos: 'Perez Perez', edad: 25, localidad: 'Santa Cruz de Tenerife', correo: 'luispp@gmail.com'},
      { id: '10', nombre: 'Javier', apellidos: 'Perez Perez', edad: 25, localidad: 'Santa Cruz de Tenerife', correo: 'javierpp@gmail.com'},
    ],
  };
  it('renders', () => {
    const div = document.createElement('div');
    ReactDOM.render(<Table {...props} />, div);
  });

  test('snapshots', () => {
    const component = renderer.create(<Table {...props } />);
    let tree = component.toJSON();
    expect(tree).toMatchSnapshot();
  });
});


describe('App', () => {

  it('renders', () => {
    const div = document.createElement('div');
    ReactDOM.render(<App />, div);
  });

  test('snapshots', () => {
    const component = renderer.create(<App />);
    let tree = component.toJSON();
    expect(tree).toMatchSnapshot();
  });
});
